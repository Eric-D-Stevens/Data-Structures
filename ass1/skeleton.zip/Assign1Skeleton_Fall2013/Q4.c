/* CS261- Assignment 1 - Q.4*/
/* Name:
 * Date:
 * Solution description:
 */
 
#include <stdio.h>
#include <stdlib.h>

struct student{
	int id;
	int score;
};

void sort(struct student* students, int n){
     /*Sort the n students based on their score*/     
     /* Remember, each student must be matched with their original score after sorting */
}

int main(){
    /*Declare an integer n and assign it a value.*/
    
    /*Allocate memory for n students using malloc.*/
    
    /*Generate random IDs and scores for the n students, using rand().*/
    
    /*Print the contents of the array of n students.*/

    /*Pass this array along with n to the sort() function*/
    
    /*Print the contents of the array of n students.*/
    
    return 0;
}
