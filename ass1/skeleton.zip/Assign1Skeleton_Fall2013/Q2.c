/* CS261- Assignment 1 - Q.2*/
/* Name:
 * Date:
 * Solution description:
 */
 
#include <stdio.h>
#include <stdlib.h>

int foo(int* a, int* b, int c){
    /*Set a to double its original value*/
    
    /*Set b to half its original value*/
    
    /*Assign a+b to c*/
    
    /*Return c*/
}

int main(){
    /*Declare three integers x,y and z and initialize them to 7, 8, 9 respectively*/
    
    /*Print the values of x, y and z*/
    
    /*Call foo() appropriately, passing x,y,z as parameters*/
    
    /*Print the value returned by foo*/
    
    /*Print the values of x, y and z again*/
 
    /*Is the return value different than the value of z?  Why?*/
    return 0;
}
    
    
